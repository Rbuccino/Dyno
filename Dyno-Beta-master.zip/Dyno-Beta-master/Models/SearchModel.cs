using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System;
namespace Dyno.Models
{
    public class Search
    {
    public string sTerm {get;set;}
    }
}